import React, { useState } from 'react';
import { 
  ShieldAlert, 
  Database, 
  Cpu, 
  Code2, 
  BarChart3, 
  Network, 
  Zap, 
  Info,
  AlertTriangle,
  CheckCircle2,
  ChevronRight,
  Layers,
  Activity,
  Search,
  Settings,
  Terminal,
  BrainCircuit
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  PieChart, 
  Pie, 
  Cell,
  LineChart,
  Line,
  AreaChart,
  Area,
  ScatterChart,
  Scatter,
  ZAxis
} from 'recharts';
import { cn } from './lib/utils';
import { CodeBlock } from './components/CodeBlock';

// --- Mock Data for Visualizations ---
const imbalanceData = [
  { name: 'Legitimate', value: 99.83, color: '#10b981' },
  { name: 'Fraudulent', value: 0.17, color: '#ef4444' },
];

const anomalyScoreData = Array.from({ length: 40 }, (_, i) => ({
  index: i,
  score: i === 25 || i === 32 ? Math.random() * 0.4 + 0.6 : Math.random() * 0.3,
  isAnomaly: i === 25 || i === 32
}));

const metricsData = [
  { name: 'Precision', value: 0.88 },
  { name: 'Recall', value: 0.82 },
  { name: 'F1-Score', value: 0.85 },
  { name: 'ROC-AUC', value: 0.96 },
];

const modelComparison = [
  { name: 'Isolation Forest', speed: 9, accuracy: 8, scalability: 9, interpretability: 7 },
  { name: 'One-Class SVM', speed: 5, accuracy: 7, scalability: 4, interpretability: 5 },
  { name: 'Autoencoders', speed: 4, accuracy: 9, scalability: 7, interpretability: 3 },
  { name: 'LOF', speed: 6, accuracy: 7, scalability: 5, interpretability: 6 },
];

// --- Python Code Snippets ---
const pythonImplementation = `
import pandas as pd
import numpy as np
from sklearn.ensemble import IsolationForest
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, confusion_matrix, precision_recall_curve
import matplotlib.pyplot as plt

# 1. Data Preprocessing
def preprocess_data(df):
    # Handle missing values
    df = df.fillna(df.median())
    
    # Normalize 'Amount' and 'Time'
    scaler = StandardScaler()
    df['Amount_Scaled'] = scaler.fit_transform(df['Amount'].values.reshape(-1, 1))
    df = df.drop(['Amount', 'Time'], axis=1)
    
    return df

# 2. Feature Engineering (Example: Behavioral Features)
def engineer_features(df):
    # In a real scenario, we'd calculate rolling averages, 
    # frequency of transactions per merchant, etc.
    # df['avg_spend_1h'] = df.groupby('card_id')['Amount'].transform(lambda x: x.rolling('1H').mean())
    return df

# 3. Model Training (Isolation Forest)
def train_anomaly_detector(X_train):
    # Contamination is the expected proportion of outliers
    model = IsolationForest(n_estimators=100, contamination=0.002, random_state=42)
    model.fit(X_train)
    return model

# 4. Evaluation
def evaluate_model(model, X_test, y_test):
    # Isolation Forest returns -1 for anomalies, 1 for normal
    y_pred = model.predict(X_test)
    y_pred = [1 if x == -1 else 0 for x in y_pred] # Map to 0 (normal), 1 (fraud)
    
    print("Confusion Matrix:\\n", confusion_matrix(y_test, y_pred))
    print("\\nClassification Report:\\n", classification_report(y_test, y_pred))

# Main Execution Flow
# data = pd.read_csv('creditcard.csv')
# processed_data = preprocess_data(data)
# X = processed_data.drop('Class', axis=1)
# y = processed_data['Class']
# X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, stratify=y)
# model = train_anomaly_detector(X_train)
# evaluate_model(model, X_test, y_test)
`;

const autoencoderCode = `
import torch
import torch.nn as nn

class FraudAutoencoder(nn.Module):
    def __init__(self, input_dim):
        super(FraudAutoencoder, self).__init__()
        # Encoder
        self.encoder = nn.Sequential(
            nn.Linear(input_dim, 32),
            nn.ReLU(),
            nn.Linear(32, 16),
            nn.ReLU(),
            nn.Linear(16, 8) # Bottleneck
        )
        # Decoder
        self.decoder = nn.Sequential(
            nn.Linear(8, 16),
            nn.ReLU(),
            nn.Linear(16, 32),
            nn.ReLU(),
            nn.Linear(32, input_dim)
        )

    def forward(self, x):
        encoded = self.encoder(x)
        decoded = self.decoder(encoded)
        return decoded

# Training logic: Minimize Reconstruction Loss (MSE)
# Anomalies will have high reconstruction error
`;

// --- UI Components ---

const NavItem = ({ icon: Icon, label, active, onClick }: any) => (
  <button
    onClick={onClick}
    className={cn(
      "flex items-center gap-3 px-4 py-3 w-full text-left transition-all duration-200 border-r-2",
      active 
        ? "bg-zinc-900 text-emerald-400 border-emerald-500" 
        : "text-zinc-500 border-transparent hover:bg-zinc-900/50 hover:text-zinc-300"
    )}
  >
    <Icon size={18} />
    <span className="text-sm font-medium">{label}</span>
  </button>
);

const Card = ({ title, children, icon: Icon, className }: any) => (
  <div className={cn("bg-zinc-900/50 border border-zinc-800 rounded-xl overflow-hidden", className)}>
    <div className="px-6 py-4 border-b border-zinc-800 flex items-center gap-3">
      {Icon && <Icon size={18} className="text-emerald-500" />}
      <h3 className="text-sm font-semibold text-zinc-200 uppercase tracking-wider">{title}</h3>
    </div>
    <div className="p-6">
      {children}
    </div>
  </div>
);

export default function App() {
  const [activeTab, setActiveTab] = useState('overview');

  const tabs = [
    { id: 'overview', label: 'Problem Definition', icon: ShieldAlert },
    { id: 'data', label: 'Data Understanding', icon: Database },
    { id: 'algorithms', label: 'Anomaly Techniques', icon: Cpu },
    { id: 'implementation', label: 'Python Implementation', icon: Code2 },
    { id: 'evaluation', label: 'Model Evaluation', icon: BarChart3 },
    { id: 'deployment', label: 'Deployment & Arch', icon: Network },
    { id: 'advanced', label: 'Advanced Topics', icon: Zap },
  ];

  return (
    <div className="min-h-screen bg-zinc-950 text-zinc-300 font-sans selection:bg-emerald-500/30 selection:text-emerald-200">
      {/* Header */}
      <header className="h-16 border-b border-zinc-800 bg-zinc-950/80 backdrop-blur-md sticky top-0 z-50 flex items-center justify-between px-8">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 bg-emerald-500 rounded-lg flex items-center justify-center">
            <ShieldAlert className="text-zinc-950" size={20} />
          </div>
          <div>
            <h1 className="text-lg font-bold text-zinc-100 tracking-tight">FraudGuard AI</h1>
            <p className="text-[10px] text-zinc-500 uppercase tracking-[0.2em] font-mono">Expert Anomaly Detection System</p>
          </div>
        </div>
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2 px-3 py-1 bg-zinc-900 rounded-full border border-zinc-800">
            <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse" />
            <span className="text-xs font-mono text-emerald-500">SYSTEM_ACTIVE</span>
          </div>
        </div>
      </header>

      <div className="flex">
        {/* Sidebar */}
        <aside className="w-64 border-r border-zinc-800 h-[calc(100vh-64px)] sticky top-16 bg-zinc-950/50">
          <nav className="py-4">
            {tabs.map((tab) => (
              <NavItem
                key={tab.id}
                icon={tab.icon}
                label={tab.label}
                active={activeTab === tab.id}
                onClick={() => setActiveTab(tab.id)}
              />
            ))}
          </nav>
          <div className="absolute bottom-0 left-0 w-full p-6 border-t border-zinc-800">
            <div className="flex items-center gap-3 text-zinc-500 mb-4">
              <Settings size={14} />
              <span className="text-xs">Configuration</span>
            </div>
            <div className="space-y-2">
              <div className="h-1 w-full bg-zinc-900 rounded-full overflow-hidden">
                <div className="h-full bg-emerald-500 w-3/4" />
              </div>
              <p className="text-[10px] font-mono uppercase">Model Confidence: 84%</p>
            </div>
          </div>
        </aside>

        {/* Main Content */}
        <main className="flex-1 p-8 overflow-y-auto">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
            >
              {activeTab === 'overview' && (
                <div className="space-y-8 max-w-5xl">
                  <section>
                    <h2 className="text-3xl font-bold text-zinc-100 mb-4">Problem Definition</h2>
                    <p className="text-lg text-zinc-400 leading-relaxed">
                      Credit card fraud detection is fundamentally an <span className="text-emerald-400 font-semibold italic">anomaly detection problem</span>. 
                      Unlike standard classification where classes are balanced, fraud represents a "needle in a haystack" scenario where 
                      the goal is to identify patterns that deviate significantly from the norm.
                    </p>
                  </section>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <Card title="The Anomaly Perspective" icon={AlertTriangle}>
                      <ul className="space-y-4 text-sm">
                        <li className="flex gap-3">
                          <ChevronRight className="text-emerald-500 shrink-0" size={16} />
                          <span><strong className="text-zinc-200">Rare Events:</strong> Fraudulent transactions typically account for less than 0.2% of total volume.</span>
                        </li>
                        <li className="flex gap-3">
                          <ChevronRight className="text-emerald-500 shrink-0" size={16} />
                          <span><strong className="text-zinc-200">Unseen Patterns:</strong> Fraudsters constantly evolve, meaning the "fraud" class is non-stationary.</span>
                        </li>
                        <li className="flex gap-3">
                          <ChevronRight className="text-emerald-500 shrink-0" size={16} />
                          <span><strong className="text-zinc-200">High Stakes:</strong> False negatives (missed fraud) lead to financial loss; False positives (blocked legit) lead to customer friction.</span>
                        </li>
                      </ul>
                    </Card>

                    <Card title="Core Challenges" icon={Activity}>
                      <div className="space-y-6">
                        <div>
                          <h4 className="text-xs font-bold text-emerald-500 uppercase mb-2">Class Imbalance</h4>
                          <div className="h-48 w-full">
                            <ResponsiveContainer width="100%" height="100%">
                              <PieChart>
                                <Pie
                                  data={imbalanceData}
                                  innerRadius={60}
                                  outerRadius={80}
                                  paddingAngle={5}
                                  dataKey="value"
                                >
                                  {imbalanceData.map((entry, index) => (
                                    <Cell key={`cell-${index}`} fill={entry.color} />
                                  ))}
                                </Pie>
                                <Tooltip 
                                  contentStyle={{ backgroundColor: '#18181b', border: '1px solid #27272a' }}
                                  itemStyle={{ color: '#d4d4d8' }}
                                />
                              </PieChart>
                            </ResponsiveContainer>
                          </div>
                          <p className="text-xs text-zinc-500 text-center mt-2 italic">Fraud accounts for ~0.17% of transactions</p>
                        </div>
                        <div className="grid grid-cols-2 gap-4">
                          <div className="p-3 bg-zinc-900/80 rounded-lg border border-zinc-800">
                            <p className="text-[10px] uppercase text-zinc-500 mb-1">Concept Drift</p>
                            <p className="text-xs">Spending habits change over time (e.g., holidays).</p>
                          </div>
                          <div className="p-3 bg-zinc-900/80 rounded-lg border border-zinc-800">
                            <p className="text-[10px] uppercase text-zinc-500 mb-1">Real-time Latency</p>
                            <p className="text-xs">Decisions must be made in &lt;100ms.</p>
                          </div>
                        </div>
                      </div>
                    </Card>
                  </div>
                </div>
              )}

              {activeTab === 'data' && (
                <div className="space-y-8 max-w-5xl">
                  <section>
                    <h2 className="text-3xl font-bold text-zinc-100 mb-4">Data Understanding</h2>
                    <p className="text-lg text-zinc-400 leading-relaxed">
                      A typical transaction dataset contains a mix of numerical, categorical, and temporal features. 
                      Understanding these is crucial for effective feature engineering.
                    </p>
                  </section>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <Card title="Raw Features" icon={Database} className="md:col-span-2">
                      <div className="grid grid-cols-2 gap-4">
                        <div className="space-y-2">
                          <h4 className="text-xs font-bold text-zinc-400 uppercase">Transactional</h4>
                          <div className="p-3 bg-zinc-950 rounded border border-zinc-800 font-mono text-xs">
                            <p>Amount: $124.50</p>
                            <p>Time: 14:02:55</p>
                            <p>Currency: USD</p>
                          </div>
                        </div>
                        <div className="space-y-2">
                          <h4 className="text-xs font-bold text-zinc-400 uppercase">Contextual</h4>
                          <div className="p-3 bg-zinc-950 rounded border border-zinc-800 font-mono text-xs">
                            <p>Merchant: Amazon</p>
                            <p>Location: Seattle, WA</p>
                            <p>Device: iPhone 15</p>
                          </div>
                        </div>
                      </div>
                      <div className="mt-6 p-4 bg-emerald-500/5 border border-emerald-500/20 rounded-lg">
                        <h4 className="text-sm font-bold text-emerald-400 mb-2 flex items-center gap-2">
                          <Info size={16} /> Preprocessing Steps
                        </h4>
                        <ul className="text-xs space-y-2 text-zinc-400">
                          <li>• <strong className="text-zinc-300">Normalization:</strong> Scaling 'Amount' using RobustScaler to handle outliers.</li>
                          <li>• <strong className="text-zinc-300">Encoding:</strong> One-hot encoding for Merchant/Category; Target encoding for high-cardinality IDs.</li>
                          <li>• <strong className="text-zinc-300">Missing Values:</strong> Imputation using median or a dedicated "Missing" category.</li>
                        </ul>
                      </div>
                    </Card>

                    <Card title="Feature Engineering" icon={BrainCircuit}>
                      <div className="space-y-4">
                        <div className="p-3 bg-zinc-900/50 rounded-lg border border-zinc-800">
                          <h5 className="text-xs font-bold text-zinc-200 mb-1">Behavioral</h5>
                          <p className="text-[11px] text-zinc-500">Average spend in last 24h vs. current transaction.</p>
                        </div>
                        <div className="p-3 bg-zinc-900/50 rounded-lg border border-zinc-800">
                          <h5 className="text-xs font-bold text-zinc-200 mb-1">Frequency</h5>
                          <p className="text-[11px] text-zinc-500">Number of transactions in the last hour.</p>
                        </div>
                        <div className="p-3 bg-zinc-900/50 rounded-lg border border-zinc-800">
                          <h5 className="text-xs font-bold text-zinc-200 mb-1">Geolocation</h5>
                          <p className="text-[11px] text-zinc-500">Distance between current and previous transaction location.</p>
                        </div>
                      </div>
                    </Card>
                  </div>
                </div>
              )}

              {activeTab === 'algorithms' && (
                <div className="space-y-8 max-w-5xl">
                  <section>
                    <h2 className="text-3xl font-bold text-zinc-100 mb-4">Anomaly Detection Techniques</h2>
                    <p className="text-lg text-zinc-400 leading-relaxed">
                      Different algorithms excel at capturing different types of anomalies. Choosing the right one 
                      depends on your data volume, dimensionality, and latency requirements.
                    </p>
                  </section>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <Card title="Isolation Forest" icon={Layers}>
                      <p className="text-sm text-zinc-400 mb-4">
                        Builds an ensemble of trees. Anomalies are easier to isolate and thus have shorter path lengths in the trees.
                      </p>
                      <div className="p-3 bg-emerald-500/10 rounded border border-emerald-500/30 text-xs text-emerald-400">
                        <strong>Best for:</strong> Large datasets, high-dimensional features, and global anomalies.
                      </div>
                    </Card>

                    <Card title="Autoencoders (DL)" icon={Network}>
                      <p className="text-sm text-zinc-400 mb-4">
                        Neural networks trained to reconstruct "normal" data. High reconstruction error signals an anomaly.
                      </p>
                      <div className="p-3 bg-blue-500/10 rounded border border-blue-500/30 text-xs text-blue-400">
                        <strong>Best for:</strong> Complex, non-linear patterns and unstructured data.
                      </div>
                    </Card>

                    <Card title="One-Class SVM" icon={Cpu}>
                      <p className="text-sm text-zinc-400 mb-4">
                        Finds a hyperplane that encloses the majority of normal data points in a high-dimensional space.
                      </p>
                      <div className="p-3 bg-amber-500/10 rounded border border-amber-500/30 text-xs text-amber-400">
                        <strong>Best for:</strong> Small to medium datasets where the boundary is well-defined.
                      </div>
                    </Card>

                    <Card title="Local Outlier Factor" icon={Search}>
                      <p className="text-sm text-zinc-400 mb-4">
                        Compares the local density of a point to its neighbors. Points with significantly lower density are outliers.
                      </p>
                      <div className="p-3 bg-purple-500/10 rounded border border-purple-500/30 text-xs text-purple-400">
                        <strong>Best for:</strong> Detecting local anomalies that might look normal globally.
                      </div>
                    </Card>
                  </div>

                  <Card title="Model Comparison Matrix" icon={BarChart3}>
                    <div className="h-64 w-full">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={modelComparison}>
                          <CartesianGrid strokeDasharray="3 3" stroke="#27272a" vertical={false} />
                          <XAxis dataKey="name" stroke="#71717a" fontSize={12} />
                          <YAxis stroke="#71717a" fontSize={12} />
                          <Tooltip 
                            contentStyle={{ backgroundColor: '#18181b', border: '1px solid #27272a' }}
                            itemStyle={{ color: '#d4d4d8' }}
                          />
                          <Bar dataKey="accuracy" fill="#10b981" name="Accuracy" radius={[4, 4, 0, 0]} />
                          <Bar dataKey="speed" fill="#3b82f6" name="Speed" radius={[4, 4, 0, 0]} />
                          <Bar dataKey="scalability" fill="#f59e0b" name="Scalability" radius={[4, 4, 0, 0]} />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                  </Card>
                </div>
              )}

              {activeTab === 'implementation' && (
                <div className="space-y-8 max-w-5xl">
                  <section>
                    <h2 className="text-3xl font-bold text-zinc-100 mb-4">Python Implementation</h2>
                    <p className="text-lg text-zinc-400 leading-relaxed">
                      Practical implementation using Scikit-Learn and PyTorch. These snippets cover the 
                      end-to-end pipeline from preprocessing to evaluation.
                    </p>
                  </section>

                  <div className="space-y-6">
                    <div>
                      <h3 className="text-sm font-bold text-emerald-500 uppercase mb-2 flex items-center gap-2">
                        <Terminal size={16} /> Scikit-Learn: Isolation Forest
                      </h3>
                      <CodeBlock code={pythonImplementation} />
                    </div>

                    <div>
                      <h3 className="text-sm font-bold text-blue-500 uppercase mb-2 flex items-center gap-2">
                        <Terminal size={16} /> PyTorch: Autoencoder Architecture
                      </h3>
                      <CodeBlock code={autoencoderCode} />
                    </div>
                  </div>
                </div>
              )}

              {activeTab === 'evaluation' && (
                <div className="space-y-8 max-w-5xl">
                  <section>
                    <h2 className="text-3xl font-bold text-zinc-100 mb-4">Model Evaluation</h2>
                    <p className="text-lg text-zinc-400 leading-relaxed">
                      In fraud detection, <span className="text-red-400">Accuracy is a trap</span>. 
                      A model that predicts "No Fraud" for every transaction would have 99.8% accuracy but 0% utility.
                    </p>
                  </section>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <Card title="Key Metrics" icon={BarChart3}>
                      <div className="space-y-6">
                        {metricsData.map((metric) => (
                          <div key={metric.name}>
                            <div className="flex justify-between text-xs mb-1">
                              <span className="text-zinc-400 font-mono">{metric.name}</span>
                              <span className="text-emerald-400 font-bold">{(metric.value * 100).toFixed(0)}%</span>
                            </div>
                            <div className="h-2 w-full bg-zinc-800 rounded-full overflow-hidden">
                              <motion.div 
                                initial={{ width: 0 }}
                                animate={{ width: `${metric.value * 100}%` }}
                                className="h-full bg-emerald-500" 
                              />
                            </div>
                          </div>
                        ))}
                      </div>
                      <div className="mt-8 p-4 bg-zinc-950 rounded-lg border border-zinc-800">
                        <p className="text-xs text-zinc-500 leading-relaxed">
                          <strong className="text-zinc-300">PR-AUC vs ROC-AUC:</strong> For highly imbalanced data, 
                          Precision-Recall AUC is often more informative than ROC-AUC as it focuses on the minority class performance.
                        </p>
                      </div>
                    </Card>

                    <Card title="Anomaly Score Distribution" icon={Activity}>
                      <div className="h-64 w-full">
                        <ResponsiveContainer width="100%" height="100%">
                          <AreaChart data={anomalyScoreData}>
                            <CartesianGrid strokeDasharray="3 3" stroke="#27272a" vertical={false} />
                            <XAxis dataKey="index" hide />
                            <YAxis stroke="#71717a" fontSize={12} />
                            <Tooltip 
                              contentStyle={{ backgroundColor: '#18181b', border: '1px solid #27272a' }}
                              itemStyle={{ color: '#d4d4d8' }}
                            />
                            <Area 
                              type="monotone" 
                              dataKey="score" 
                              stroke="#10b981" 
                              fill="#10b981" 
                              fillOpacity={0.1} 
                            />
                            {/* Visual indicator for anomalies */}
                            <Line type="monotone" dataKey="score" stroke="transparent" dot={(props: any) => {
                              const { cx, cy, payload } = props;
                              if (payload.isAnomaly) {
                                return (
                                  <circle cx={cx} cy={cy} r={4} fill="#ef4444" stroke="#ef4444" />
                                );
                              }
                              return null;
                            }} />
                          </AreaChart>
                        </ResponsiveContainer>
                      </div>
                      <div className="flex justify-center gap-6 mt-4">
                        <div className="flex items-center gap-2">
                          <div className="w-3 h-3 bg-emerald-500 rounded-full" />
                          <span className="text-[10px] uppercase text-zinc-500">Normal</span>
                        </div>
                        <div className="flex items-center gap-2">
                          <div className="w-3 h-3 bg-red-500 rounded-full" />
                          <span className="text-[10px] uppercase text-zinc-500">Anomaly (Fraud)</span>
                        </div>
                      </div>
                    </Card>
                  </div>
                </div>
              )}

              {activeTab === 'deployment' && (
                <div className="space-y-8 max-w-5xl">
                  <section>
                    <h2 className="text-3xl font-bold text-zinc-100 mb-4">Deployment Architecture</h2>
                    <p className="text-lg text-zinc-400 leading-relaxed">
                      A production fraud detection system must be resilient, low-latency, and integrated 
                      deeply into the transaction flow.
                    </p>
                  </section>

                  <Card title="Real-time Pipeline Workflow" icon={Network}>
                    <div className="relative py-12">
                      <div className="flex flex-col md:flex-row items-center justify-between gap-8">
                        {[
                          { label: 'Transaction Event', icon: Zap, color: 'bg-zinc-800' },
                          { label: 'Feature Enrichment', icon: Database, color: 'bg-zinc-800' },
                          { label: 'Model Inference', icon: BrainCircuit, color: 'bg-emerald-500 text-zinc-950' },
                          { label: 'Decision Engine', icon: Settings, color: 'bg-zinc-800' },
                          { label: 'Action (Approve/Block)', icon: CheckCircle2, color: 'bg-zinc-800' },
                        ].map((step, i, arr) => (
                          <React.Fragment key={step.label}>
                            <div className="flex flex-col items-center gap-3 z-10">
                              <div className={cn("w-16 h-16 rounded-2xl flex items-center justify-center shadow-lg border border-zinc-700", step.color)}>
                                <step.icon size={24} />
                              </div>
                              <span className="text-[10px] font-bold uppercase tracking-wider text-center w-24">{step.label}</span>
                            </div>
                            {i < arr.length - 1 && (
                              <div className="hidden md:block flex-1 h-px bg-zinc-800 relative">
                                <ChevronRight className="absolute -right-2 -top-2 text-zinc-700" size={16} />
                              </div>
                            )}
                          </React.Fragment>
                        ))}
                      </div>
                    </div>
                  </Card>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <Card title="Model Serving" icon={Cpu}>
                      <ul className="space-y-4 text-sm">
                        <li className="flex gap-3">
                          <CheckCircle2 className="text-emerald-500 shrink-0" size={16} />
                          <span><strong className="text-zinc-200">REST/gRPC API:</strong> Serving models via FastAPI or TorchServe for sub-50ms latency.</span>
                        </li>
                        <li className="flex gap-3">
                          <CheckCircle2 className="text-emerald-500 shrink-0" size={16} />
                          <span><strong className="text-zinc-200">Feature Store:</strong> Using Redis or Feast to retrieve historical user features in real-time.</span>
                        </li>
                        <li className="flex gap-3">
                          <CheckCircle2 className="text-emerald-500 shrink-0" size={16} />
                          <span><strong className="text-zinc-200">Shadow Mode:</strong> Running new models in parallel with production to validate performance before cutover.</span>
                        </li>
                      </ul>
                    </Card>
                    <Card title="Integration" icon={Settings}>
                      <p className="text-sm text-zinc-400 mb-4">
                        Integration with core banking systems often involves message queues (Kafka) for asynchronous 
                        logging and synchronous API calls for blocking decisions.
                      </p>
                      <div className="p-4 bg-zinc-950 rounded border border-zinc-800 font-mono text-[10px] text-zinc-500">
                        POST /v1/fraud-check<br/>
                        {`{ "transaction_id": "tx_9823", "amount": 450.00, ... }`}<br/><br/>
                        RESPONSE 200 OK<br/>
                        {`{ "score": 0.92, "action": "BLOCK", "reason": "GEO_ANOMALY" }`}
                      </div>
                    </Card>
                  </div>
                </div>
              )}

              {activeTab === 'advanced' && (
                <div className="space-y-8 max-w-5xl">
                  <section>
                    <h2 className="text-3xl font-bold text-zinc-100 mb-4">Advanced Topics</h2>
                    <p className="text-lg text-zinc-400 leading-relaxed">
                      Staying ahead of fraudsters requires sophisticated techniques like online learning 
                      and explainable AI.
                    </p>
                  </section>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <Card title="Concept Drift & Online Learning" icon={Zap}>
                      <p className="text-sm text-zinc-400 mb-4">
                        Fraud patterns change. Static models degrade. Online learning allows models to 
                        update incrementally as new data arrives.
                      </p>
                      <div className="space-y-2">
                        <div className="flex items-center justify-between text-[10px] uppercase text-zinc-500">
                          <span>Model Performance</span>
                          <span>Time →</span>
                        </div>
                        <div className="h-24 w-full">
                          <ResponsiveContainer width="100%" height="100%">
                            <LineChart data={[
                              { t: 0, v: 95, v2: 95 },
                              { t: 1, v: 92, v2: 94 },
                              { t: 2, v: 85, v2: 93 },
                              { t: 3, v: 78, v2: 94 },
                              { t: 4, v: 70, v2: 92 },
                            ]}>
                              <Line type="monotone" dataKey="v" stroke="#ef4444" strokeWidth={2} dot={false} name="Static Model" />
                              <Line type="monotone" dataKey="v2" stroke="#10b981" strokeWidth={2} dot={false} name="Online Learning" />
                            </LineChart>
                          </ResponsiveContainer>
                        </div>
                      </div>
                    </Card>

                    <Card title="Explainable AI (XAI)" icon={Info}>
                      <p className="text-sm text-zinc-400 mb-4">
                        Why was a transaction blocked? XAI (using SHAP or LIME) provides feature-level 
                        explanations for human investigators.
                      </p>
                      <div className="space-y-2">
                        <h5 className="text-[10px] font-bold uppercase text-zinc-500">SHAP Values (Example)</h5>
                        <div className="space-y-1">
                          <div className="flex items-center gap-2">
                            <span className="text-[10px] w-20">Amount</span>
                            <div className="h-2 flex-1 bg-emerald-500/20 rounded-full overflow-hidden">
                              <div className="h-full bg-emerald-500 w-3/4" />
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            <span className="text-[10px] w-20">Distance</span>
                            <div className="h-2 flex-1 bg-emerald-500/20 rounded-full overflow-hidden">
                              <div className="h-full bg-emerald-500 w-1/2" />
                            </div>
                          </div>
                          <div className="flex items-center gap-2">
                            <span className="text-[10px] w-20">Time_of_Day</span>
                            <div className="h-2 flex-1 bg-red-500/20 rounded-full overflow-hidden">
                              <div className="h-full bg-red-500 w-1/4" />
                            </div>
                          </div>
                        </div>
                      </div>
                    </Card>
                  </div>

                  <div className="p-6 bg-emerald-500/5 border border-emerald-500/20 rounded-xl">
                    <h3 className="text-lg font-bold text-emerald-400 mb-4 flex items-center gap-2">
                      <Zap size={20} /> Bonus: Hybrid Approaches
                    </h3>
                    <p className="text-sm text-zinc-400 leading-relaxed mb-4">
                      The most robust systems use <strong className="text-zinc-200">Ensemble Hybrids</strong>. 
                      Combining a rule-based engine (for known fraud) with an unsupervised anomaly detector (for novel fraud) 
                      and a supervised classifier (for historical patterns) provides the best coverage.
                    </p>
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div className="p-3 bg-zinc-900 rounded-lg border border-zinc-800 text-center">
                        <p className="text-xs font-bold text-zinc-300">Rules Engine</p>
                        <p className="text-[10px] text-zinc-500">Deterministic & Fast</p>
                      </div>
                      <div className="p-3 bg-zinc-900 rounded-lg border border-zinc-800 text-center">
                        <p className="text-xs font-bold text-zinc-300">Anomaly ML</p>
                        <p className="text-[10px] text-zinc-500">Detects Unknowns</p>
                      </div>
                      <div className="p-3 bg-zinc-900 rounded-lg border border-zinc-800 text-center">
                        <p className="text-xs font-bold text-zinc-300">Graph Analysis</p>
                        <p className="text-[10px] text-zinc-500">Detects Fraud Rings</p>
                      </div>
                    </div>
                  </div>
                </div>
              )}
            </motion.div>
          </AnimatePresence>
        </main>
      </div>
    </div>
  );
}
